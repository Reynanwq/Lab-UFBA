// package exercicio_incremental;

/*
Proprietarios podem ter um ou mais Imoveis disponíveis para locação. 
Refatore o sistema para representar essa relação e implemente uma nova funcionalidade que permita que,
dado um tipo de Imovel ("casa", "apto", ...), liste na tela os Imoveis de um Proprietario com o tipo determinado.
Obs: Imoveis podem ser cadastrados independentemente de Proprietarios   
*/
import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;
import exercicio_incremental.Endereco;
import exercicio_incremental.Imovel;

public class Proprietario{
    
   private String nome;
   private String cpf;
   private String identidade;
   private Endereco endereco;
   private List<Imovel> imoveis = new ArrayList<>();
   // adicionando um atributo imovel que será uma lista de objetos da classe imovel

   /*------ Construtores --------*/

   public Proprietario(String nome, String cpf, String identidade, Endereco endereco){
        this.nome = nome;
        this.cpf = cpf;
        this.identidade = identidade;
        this.endereco = endereco;
        this.imoveis = new ArrayList<>();
   }

  /* */
   
   /*------ Metodos get --------*/

    public String getNome(){
       return this.nome;
    }
    
    public String getCpf(){
       return this.cpf;
    }
    
    public String getIdentidade(){
       return this.identidade;
    }
   
   /*------ Metodos set --------*/
   
   public void setNome(String nome){
       this.nome = nome;
   }
   
   public void setCpf(String cpf){
       this.cpf = cpf;
   }
   
   public void setIdentidade(String identidade){
       this.identidade = identidade;
   }
   
   /*----- Metodo para adicionar imovel --------*/
   
   public void addImovel(Imovel imovel){
       this.imoveis.add(imovel);
   }
   
   /*----- Listas imoveis pelo tipo -------------*/
   public void listarImoveisPeloTipo(String tipo){
       System.out.println("Imóveis do tipo " + tipo + " do proprietário " + this.nome + ":");
       for (Imovel imovel : this.imoveis) { 
           if (imovel.getTipo().equals(tipo)){
               System.out.println("- " + endereco.getRua() + ", " + endereco.getNumero() + ", " + endereco.getCidade() + ", " + endereco.getEstado() + " - " + imovel.getUtilizacao());
           }
       }
   }
  
/*--------- cadastrar imovel --------*/

/*Para cadastrar um imóvel, o sistema deve perguntar ao usuário o valor do iptu, o nome da rua, o número da casa/prédio, o cep, o nome do estado, o nome da cidade, o tipo de imóvel, e sua utilização.*/
  
 public ovid cadastrarImovel(){
   Scanner scanner = new Scanner(System.in); //chamando o metodo
   System.out.println("Cadastro de Imoveis");
   
   System.out.print("Valor do IPTU: ");
    int iptu = scanner.nextInt();
    scanner.nextLine();

   System.out.print("Nome da rua: ");
    String rua = scanner.nextLine();

   System.out.println("Numero da casa/prédio: ");
   String numero = scanner.nextLine();

   System.out.println("Numero do CEP: ");
   String cep = scaner.nextLine();

   System.out.println("Nome do estado: ");
   String estado = scanner.nextLine();

   System.out.println("Nome da cidade: ");
   String cidade = scanner.nextLine();

   System.out.println("Tipo do Imovel: ");
   String tipo = scanner.nextLine();

   System.out.println("Utilizacao do imovel: ");
   String utilizacao = scanner.nextLine();

        System.out.println("Imovel cadastrado com sucesso!");
        System.out.println();
  }       

  /*O sistema de imóveis já está quase pronto, mas agora é necessário permitir que os usuários possam cadastrar imóveis e proprietários e também agendar o bloqueio de imóveis dado um proprietário.*/



  
/*Para cadastrar um proprietário, o sistema deve perguntar ao usuário o nome do proprietário, seu CPF, sua identidade, e seu endereço de residência, com o número da casa/prédio, CEP, o nome do estado e o nome da cidade.*/

  /*cadastrar proprietario*/
  public void cadastrarProprietario(){
    Scanner scanner = new Scanner(System.in);
    System.out.println("Cadastro de Funcionario");

    System.out.println("Nome do Proprietario: ");
    String nome = scanner.nextLine();

    System.out.println("Numero do CPF: ");
    String cpf = scanner.nextLine();

    System.out.println("Numero de Identidade: ");
    String identidade = scanner.nextLine();

    System.out.println("Endereco de residencia: ");
    String endereco = scanner.nextLine();

    System.out.println("Numero da casa/predio: ");
    Int NumeroCasa = scanner.nextInt();

    System.out.println("Numero do CEP: ");
    String cep = scanner.nextLine();
    
    System.out.println("Nome do estado: ");
    String estado = scanner.nextLine();
    
    System.out.println("Nome da cidade: ");
    String cidade = scanner.nextLine();

         System.out.println("Proprietário cadastrado com sucesso!");
        System.out.println();
  }
 }
